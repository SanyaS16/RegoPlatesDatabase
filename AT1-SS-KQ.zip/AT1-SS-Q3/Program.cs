﻿using System;

namespace MyApp

{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Sanya Saddi - 30092329  
            // 25/07/2024 
            // Menu Options (AT1-SS-Q3) 
            // Question 3. Menu options vary from 1 to 7 each number (except 7) contains information about programming. Options 7 quits the program. 
            // The user is required to input a number between 1 to 7 each number reveals information about certain coding aspects, except 7 which output quits the program, if the input is not an integer the default message is ‘Input is not an integer between 1 and 7’. 


            int option = 0;

            do
            {
                Console.ForegroundColor = ConsoleColor.White; // text colour set to white
                Console.WriteLine("\nEnter a number between 1 and 7 for information: \n\t1. Syntax Definition\n\t2. Syntax Rules\n\t3. Small Scale App Dev\n\t4. Document Design Definition\n\t5. Coding Techniques Definition\n\t6. Coding Standards Definition\n\t7. Quit Program\n");
                // displays menu option (1 to 7)
                Console.ForegroundColor = ConsoleColor.Green; // text colour set to green
                bool KeyBoardInput = int.TryParse(Console.ReadLine(), out option);
                // Reads the input from the user and converts it into an integer

                switch (option)
                {
                    case 1:
                        // when 1 is entered below is printed
                        Console.WriteLine("The syntax of a programming language refers to the set of rules that define the \nstructure and format of valid statements and expressions in that language. ");
                        break;
                    case 2:
                        // when 2 is entered below is printed
                        Console.WriteLine("Programming languages include syntax rules that specify the structure and format \nthat code must adhere to in order to be accepted. These guidelines guarantee that \nthe code can be correctly analysed and understood by the compiler or interpreter. \nAn example of a syntax rule in C# is that every statement must end with a semicolon \n(“;”). Another example is that the C# compiler is case sensitive and that “MyClass” \nand “myclass” have different meanings. ");
                        break;
                    case 3:
                        // when 3 is entered below is printed
                        Console.WriteLine("Small-scale application development is the process of creating software programs \nwith limited scope and low complexity, usually for a small user base or a specific \nniche market. In comparison to large-scale or enterprise-level applications, these \nprojects usually involve fewer resources, shorter development timeframes, and \nsimpler technological requirements. ");
                        break;
                    case 4:
                        // when 4 is entered below is printed
                        Console.WriteLine("Document Design Principles refer to a set of guidelines and best practices for \norganizing and presenting information in a document to enhance its readability, \nusability, and overall effectiveness. These principles ensure that the document \ncommunicates its content clearly and efficiently to its intended audience. ");
                        break;
                    case 5:
                        // when 5 is entered below is printed
                        Console.WriteLine("In general-purpose programming, \"coding techniques\" refers to methods we could \nuse to enhance the readability, manageability, and performance of our code.");
                        break;
                    case 6:
                        // when 6 is entered below is printed
                        Console.WriteLine("Coding standards are a set of best practices and rules designed to guarantee the \nreadability, uniformity, and maintainability of code. Many aspects of coding, \nincluding name conventions, code formatting, indentation, documentation, and \nerror handling, are frequently covered by these standards. Following coding \nguidelines makes code easier to read, evaluate, and collaborate on, which can \nenhance the overall quality of software and lower the probability of errors. ");
                        break;
                    case 7:
                        // when 7 is entered it quits the program
                        Console.WriteLine("Program Ended");
                        break;
                    default:
                        // if the input is not a valid integer (between 1 and 7) below is printed
                        Console.WriteLine("Input is not an integer between 1 and 7");
                        break;
                }
            } while (option != 7); // loop runs till option is not equal to 7
        }
    }
}