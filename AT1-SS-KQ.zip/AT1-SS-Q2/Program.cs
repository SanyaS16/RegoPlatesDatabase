﻿using System;


// Sanya Saddi, 30092329 
// 29/06/2024 
// UV Index (AT1-SS-Q2) 
// Question 2. The program asks the user for the current UV index. Through the use of fall through, different UV index input return whether it is either low, moderate, high, very high, and extreme in their corresponding colours (green, yellow, orange, red, purple). 
// The user inputs the current UV index; the output corresponds to the input. If the UV is 1 or 2 output is low in green; 3, 4,5 output is Moderate in yellow; 6, 7 output is High in orange; 8, 9, 10 output is Very High in red; if 11 and above is entered output is extreme in purple (if an integer is not entered default output is “The integer input is not valid”). 


namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int UVindex;
            bool keyBoardInput;

            Console.WriteLine("What is the UV index right now?");
            keyBoardInput = int.TryParse(Console.ReadLine(), out UVindex);
            // takes user input and stores it in boolean variable keyBoardInput
            if (keyBoardInput)
            {
                switch (UVindex)
                {
                    case 1:
                        // fall through to case 2
                    case 2:
                        // if 1 or 2 is inputted then font color is changed to white and background to green and 'Low' is printed
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.WriteLine("Low");
                        break;
                    case 3:
                        // fall through to case 5
                    case 4:
                        // fall through to case 5
                    case 5:
                        // if 3-5 is inputted then font color is changed to red and background to yellow and 'Moderate' is printed
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Moderate");
                        break;
                    case 6:
                        // fall through to case 7
                    case 7:
                        // if 6 or 7 is inputted then font color is changed to white and background to red and 'High' is printed
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.WriteLine("High");
                        break;
                    case 8:
                        // fall throough to case 8
                    case 9:
                        // fall throough to case 8
                    case 10:
                        // if 8-10 is inputted then font color is changed to white and background to dark red and 'Very high' is printed
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Very High");
                        break;
                    case 11:
                        // if 11 is inputted then font color is changed to white and background to dark magenta and 'Extreme' is printed
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine("Extreme");
                        break;
                    default:
                        Console.WriteLine("The integer input is not valid");
                        // if integer input it greater than 11 or less than 1 this message is printed
                        break;
                }
            }
        }
    }
}