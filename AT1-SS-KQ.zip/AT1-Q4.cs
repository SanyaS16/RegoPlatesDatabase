﻿using System;

namespace MyApp
{
    internal class Program
    {
        // Sanya Saddi - 30092329
        // 12/08/2024
        // Twin prime and Perfect prime (AT1-SS-Q4)
        // Question 4. This console application asks the user for a maximum number, which then lists all the perfect numbers up to the set maximum limit. It then lists all the Twin Primes between 3 to 200.
        // Console application asks for user input ("Enter maximum number for Perfect Number finder:"), using the input the console prints all the perfect numbers up to the number. Then it prints all the Twin Primes from 3 to 200 for the user.

        static void Main(string[] args)
        {
            Console.WriteLine("Enter maximum number for Perfect Number finder: ");

            int maxPerfectNumber = Convert.ToInt32(Console.ReadLine());
            PerfectNumber(maxPerfectNumber);

            Console.WriteLine("\nTwin Primes from 3 to 200: \n");
            TwinPrimes();

            Console.WriteLine("\n\nPress Enter to exit program");

            Console.ReadLine();
        }
        #region Calculations
        /// <summary>
        /// This method returns the perfect numbers from 0 to set max number
        /// </summary>
        /// <param name="maxPerfectNumber">Holds the value of user input (max number Perfect Numbers will print to)</param>
        static void PerfectNumber(int maxPerfectNumber)
        {
            int divisor, sum;

            for (int counter = 0; counter <= maxPerfectNumber; counter++)
            {
                sum = 0;

                for (divisor = 1; divisor < counter; divisor++)
                {
                    if (counter % divisor == 0)
                        sum += divisor;
                }

                if (sum == counter && counter != 0)
                {
                    Console.WriteLine("Perfect number is {0}", counter);
                }
            }
        }
        /// <summary>
        /// Checks if the number is prime
        /// </summary>
        static void TwinPrimes()
        {
            int twinPrimeChecker; // calculates the 'number + 2'

            int firstPrime = 0;// checks if number is prime
            int secondPrime = 0; // checks if second number is prime

            for (int i = 3; i < 200; i++)
            {
                for (int j = 2; j < i; j++)
                {

                    if (i % j == 0)
                    {
                        firstPrime++;
                        break;
                    }
                }
                twinPrimeChecker = i + 2;

                for (int k = 2; k < i; k++)
                {
                    if (twinPrimeChecker % k == 0)
                    {
                        secondPrime++;
                        break;
                    }
                }
                if (firstPrime == 0 && secondPrime == 0)
                {
                    Console.WriteLine("Twin primes are {0}, {1}", i, twinPrimeChecker);
                }

                firstPrime = 0;
                secondPrime = 0;

            }
        }
        #endregion
    }
}