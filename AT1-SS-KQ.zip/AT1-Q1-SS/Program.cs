﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Sanya Saddi - 30092329
            // 25/07/2024
            // Hydroelectric damn (AT1-SS-Q1) 
            // Question 1. Asks for user input for the dam flow rate, the output is either a warning letting the user know if the flow rate is too high or low or is if the flow rate is okay.  
            // First asks for the flow rate of the water, if user input is less than 75 that means the flow rate is low (output is a warning); if user input is more than 120 that means the flow rate is high (outputs a warning); if the flowrate is between 75 and 120 the output is ‘Flow rate OK’. If inputed value is not an integer an error message is outputed. 

            int flowrate;

            Console.WriteLine("What is the flow rate?");
            bool keyBoardInput = int.TryParse(Console.ReadLine(), out flowrate);
            // takes input from the user

            // if statement checks if input is a valid integer
            if (!keyBoardInput || flowrate < 0)
            {
                // if not valid then prints the message and ends the program
                Console.WriteLine("User input is not a valid integer");
                return; // ends the program
            }

            if (flowrate < 75 )
            {
                // if flow rate is between 0 and 75 warning message is printed
                Console.WriteLine("Warning Flow Rate Low");
            }
            
            else if (flowrate > 120)
            {
                // if flow rate is greater than 120 warning message is printed
                Console.WriteLine("Warning Flow Rate High");
            }
            else
            {
                // if flow rate between 75 and 120 message is printed
                Console.WriteLine("Flow Rate OK");
            }
        }
    }
}